FactoryBot.define do
  factory :comment do
    comment "MyText"
    user nil
    message nil
  end
end
